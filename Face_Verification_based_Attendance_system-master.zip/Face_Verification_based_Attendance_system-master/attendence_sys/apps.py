from django.apps import AppConfig


class AttendenceSysConfig(AppConfig):
    name = 'attendence_sys'
